# RARBG IPFS Project

## Directory Structure
- `data/` \
  The original `rarbg_db.sqlite` and the derivative `rarbg_db_ipfs.sqlite` SQLite databases.
- `publish/` \
  Final result, whose content is to be pinned on IPFS.
- `scripts/` \
  Helper scripts (currently for working with the databases).
- `web/` \
  Web interface sources.

## Dependencies
- node.js
	- Use the "Active LTS" version, currently at v14.
	- See https://nodejs.org/en/download/package-manager/
- sqlite3
	- A relatively recent version shall suffice.

## Usage
1. Download `rarbg_db.zip` ([HTTPS](https://the-eye.eu/public/Random/rarbg/rarbg_db.zip), [Magnet](magnet:?xt=urn:btih:ulfihylx35oldftn7qosmk6hkhsjq5af)).
2. Run `make publish` to package the project.

### Notes
- To publish on IPFS:
  ```bash
  ipfs add --pin -r -Q -s size-65536 --raw-leaves publish/
  ```

## See Also
- [Hosting SQLite databases on Github Pages (or any static file hoster)](https://phiresky.github.io/blog/2021/hosting-sqlite-databases-on-github-pages/)
- [phiresky/sql.js-httpvfs](https://github.com/phiresky/sql.js-httpvfs)
- [sql-js/sql.js](https://github.com/sql-js/sql.js)
