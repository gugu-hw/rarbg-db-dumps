#!/usr/bin/env python3
from datetime import datetime
import sqlite3

catmap = {
    "ebooks": 1,
    "games_pc_iso": 2,
    "games_pc_rip": 3,
    "games_ps3": 4,
    "games_ps4": 5,
    "games_xbox360": 6,
    "movies_bd_full": 7,
    "movies_bd_remux": 8,
    "movies_x264_3d": 9,
    "movies_x264_4k": 10,
    "movies_x264_720": 11,
    "movies_x264": 12,
    "movies_x265_4k_hdr": 13,
    "movies_x265_4k": 14,
    "movies_x265": 15,
    "movies_xvid_720": 16,
    "movies_xvid": 17,
    "movies": 18,
    "music_flac": 19,
    "music_mp3": 20,
    "software_pc_iso": 21,
    "tv_sd": 22,
    "tv_uhd": 23,
    "tv": 24,
    "xxx": 25,
}


def main():
    with sqlite3.connect(":memory:") as to:
        to.executescript(
            """
            PRAGMA journal_mode = OFF;
            PRAGMA ignore_check_constraints = OFF;
            PRAGMA page_size = 65536;

            CREATE TABLE "items" (
                "hash"   BLOB    NOT NULL,
                "title"  TEXT    NOT NULL,
                "dt"     INTEGER NOT NULL,
                "cat"    INTEGER NOT NULL,
                "size"   INTEGER,
                "ext_id" TEXT,
                "imdb"   TEXT
            );

            CREATE VIRTUAL TABLE "items_fts" USING fts4(
                "title",
                matchinfo='fts3',
                content='items',
                tokenize=unicode61 "remove_diacritics=2"
            );           
        """
        )

        with sqlite3.connect("data/rarbg_db.sqlite") as from_:
            for _id, hash_, title, dt, cat, size, ext_id, imdb in from_.execute(
                "SELECT * FROM items ORDER BY title;"
            ):
                to.execute(
                    "INSERT INTO items VALUES(?, ?, ?, ?, ?, ?, ?)",
                    (
                        bytes.fromhex(hash_),
                        title,
                        int(datetime.strptime(dt, "%Y-%m-%d %H:%M:%S").timestamp()),
                        catmap[cat],
                        size,
                        ext_id,
                        imdb
                    ),
                )

        to.executescript(
            """
            INSERT INTO items_fts(docid, title) SELECT rowid, title FROM items;
            INSERT INTO "items_fts"("items_fts") VALUES('optimize');
            VACUUM INTO 'data/rarbg_db_ipfs.sqlite';
        """
        )


if __name__ == "__main__":
    main()
