README
======

Starting the HTTP Server
------------------------
On Windows (using cmd.exe aka the "Command Prompt"):
    .\redbean-2.2.com -s -D . -l 127.0.0.1 -p 7671

On Linux, macOS, and *BSD:
    bash -c './redbean-2.2.com -s -D . -l 127.0.0.1 -p 7671'

Using
-----
Visit http://127.0.0.1:7671/ on your web browser.

Alternatives
------------
Alternatively, you may also upload the contents of this directory to
an existing web server or a static hosting provider (such as GitHub
pages, GitLab pages, Netlify, Cloudflare Pages, ...); self-hosting is
recommended!


--------------------
https://the-eye.eu/public/Random/rarbg/rarbg_db.zip
magnet:?xt=urn:btih:ulfihylx35oldftn7qosmk6hkhsjq5af
