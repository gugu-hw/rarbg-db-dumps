import { createDbWorker, WorkerHttpvfs } from "sql.js-httpvfs";

const workerUrl = new URL(
	"sql.js-httpvfs/dist/sqlite.worker.js",
	import.meta.url
);
const wasmUrl = new URL("sql.js-httpvfs/dist/sql-wasm.wasm", import.meta.url);

const resultsEl = document.querySelector<HTMLElement>("#resultsDiv");
const buttonEl = document.querySelector<HTMLInputElement>('input[type="submit"]');
const loadButton = document.querySelector<HTMLButtonElement>("button");
const fieldsetEl = document.querySelector<HTMLFieldSetElement>("fieldset");

const resultsPerPage = 10;
let currentQuery = "";
let resultsOffset = 0;

let worker: WorkerHttpvfs | null = null;

const catmap = [
	"unknown",
	"ebooks",
	"games_pc_iso",
	"games_pc_rip",
	"games_ps3",
	"games_ps4",
	"games_xbox360",
	"movies_bd_full",
	"movies_bd_remux",
	"movies_x264_3d",
	"movies_x264_4k",
	"movies_x264_720",
	"movies_x264",
	"movies_x265_4k_hdr",
	"movies_x265_4k",
	"movies_x265",
	"movies_xvid_720",
	"movies_xvid",
	"movies",
	"music_flac",
	"music_mp3",
	"software_pc_iso",
	"tv_sd",
	"tv_uhd",
	"tv",
	"xxx",
];

async function initialize(): Promise<WorkerHttpvfs> {
	return await createDbWorker(
		[
			{
				from: "inline",
				config: {
					serverMode: "full",
					url: "../rarbg_db_ipfs.sqlite",
					requestChunkSize: 65536,
				},
			},
		],
		workerUrl.toString(),
		wasmUrl.toString()
	);
}

async function query(q: string, limit: Number, offset: Number): Promise<Array<any>> {
	const sql = `
		SELECT
			  i.rowid     as id
			, i.title     as title
			, hex(i.hash) as hash
			, i.size      as size
			, i.cat       as cat
		FROM items_fts f
		INNER JOIN items i ON i.rowid = f.docid
		WHERE items_fts MATCH ? LIMIT ? OFFSET ?;
	`;
	const params = [q, limit, offset];
	try {
		let results = await worker?.db.query(sql, params);
		currentQuery = q;
		return results;
	} catch (err) {
		console.error("Database query failed\n", {
			sql: sql,
			params: params,
			error: err,
		});

		const matches = err.message.match(/Status: ([0-9]{3})/);
		if (matches == null) {
			alert(`Database query failed!`);
		} else {
			const httpStatus = parseInt(matches[1]);
			// Observed HTTP status codes for rate limiting...
			if ([403, 429].includes(httpStatus)) {
				alert(`IPFS Gateway error (${httpStatus}), please try another gateway or use IPFS directly instead.`);
			} else {
				alert(`Database query failed (${httpStatus}), please contact the developers!`);
			}
		}

		throw err;
	}
}

function appendResults(results: Array<any>) {
	for (const item of results) {
		resultsEl!.innerHTML += `
		<div class="magnet"><a href="magnet:?xt=urn:btih:${item.hash}">🧲</a></div>
		<div class="title"><a href="magnet:?xt=urn:btih:${item.hash}">${item.title} <span class="magnet">🧲</span></a></div>
		<div class="filesize">${(item.size / (1024 * 1024 * 1024)).toFixed(1)} GiB</div>
		<div class="category">${catmap[item.cat || 0]}</div>
		`;
	}
}

document.getElementsByTagName("form")[0].addEventListener("submit", async function (ev) {
	ev.preventDefault();

	document.getElementById("welcome")!.style.display = "none";
	loadButton!.style.display = "block";

	resultsEl!.style.display = "none";
	fieldsetEl!.disabled = true;
	buttonEl!.value = "Searching...";
	loadButton!.disabled = true;

	const q = document.getElementsByTagName("input")[0].value;
	resultsOffset = 0;
	const results = await query(q, resultsPerPage, resultsOffset);

	fieldsetEl!.disabled = false;
	buttonEl!.value = "Search";

	if (results.length === 0) {
		loadButton!.textContent = "No More Results!";
		resultsEl!.style.display = "block";
		resultsEl!.innerHTML = `<div style="text-align: center;">No results have been found!</div>`;
	} else {
		loadButton!.textContent = "Load More Results";
		loadButton!.disabled = false;
		resultsEl!.style.display = "inline-grid";
		resultsEl!.textContent = "";
		appendResults(results);
	}
});

document.getElementsByTagName("button")[0].addEventListener("click", async function (ev) {
	ev.preventDefault();

	fieldsetEl!.disabled = true;
	loadButton!.disabled = true;
	loadButton!.textContent = "Loading More Results...";

	resultsOffset += resultsPerPage;
	const results = await query(currentQuery, resultsPerPage, resultsOffset);

	fieldsetEl!.disabled = false;

	if (results.length === 0) {
		loadButton!.disabled = true;
		loadButton!.textContent = "No More Results!";
	} else {
		loadButton!.disabled = false;
		loadButton!.textContent = "Load More Results";
		appendResults(results);
	}
});

initialize().then(
	(value) => {
		console.log("DB worker has been created successfully");
		worker = value;

		fieldsetEl!.disabled = false;
		buttonEl!.value = "Search";

		(document.querySelector('input[autofocus]') as HTMLElement)!.focus();
	},
	(err) => {
		console.error("DB worker could not be created\n", {
			error: err,
		});
		alert(`DB worker could not be created\n\n${err}`);
	}
);

